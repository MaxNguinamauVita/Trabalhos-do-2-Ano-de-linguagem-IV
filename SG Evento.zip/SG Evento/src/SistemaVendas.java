import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SistemaVendas {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");

        int[] numeros = new int[100];
        String[] nomes = new String[100];
        double[] valores = new double[100];
        int[] formas = new int[100];
        double[] totais = new double[100];
        int[] prestacoes = new int[100];
        String[] datas = new String[100];

        int contador = 0;
        boolean continuar = true;

        while (continuar) {
            System.out.println("\n=== MENU ===");
            System.out.println("1. Registar venda");
            System.out.println("2. Listar vendas");
            System.out.println("3. Sair");
            System.out.print("Opcao: ");
            int opcao = scanner.nextInt();

            if (opcao == 1) {
                numeros[contador] = contador + 1;

                System.out.print("Nome do cliente: ");
                nomes[contador] = scanner.next();

                System.out.print("Valor da compra (preco da etiqueta): ");
                valores[contador] = scanner.nextDouble();

                System.out.println("Forma de pagamento:");
                System.out.println("1. A vista (10% desconto)");
                System.out.println("2. 2 prestacoes (sem juros)");
                System.out.println("3. 3 a 10 prestacoes (3% juros/mes, minimo 10000)");
                System.out.print("Escolha: ");
                formas[contador] = scanner.nextInt();

                if (formas[contador] == 1) {
                    totais[contador] = valores[contador] - (valores[contador] * 0.10);
                    prestacoes[contador] = 1;
                    System.out.println("Total com desconto: " + String.format("%.2f", totais[contador]));

                } else if (formas[contador] == 2) {
                    totais[contador] = valores[contador];
                    prestacoes[contador] = 2;
                    System.out.println("Valor por prestacao: " + String.format("%.2f", totais[contador] / 2));

                } else if (formas[contador] == 3) {
                    if (valores[contador] < 10000) {
                        System.out.println("Indisponivel: valor inferior a 10.000. Operacao cancelada.");
                        continue;
                    }
                    System.out.print("Numero de prestacoes (3 a 10): ");
                    int np = scanner.nextInt();
                    if (np < 3 || np > 10) {
                        System.out.println("Numero de prestacoes invalido. Operacao cancelada.");
                        continue;
                    }
                    prestacoes[contador] = np;
                    double totalComJuros = valores[contador];
                    for (int i = 0; i < np; i++) {
                        totalComJuros = totalComJuros * 1.03;
                    }
                    totais[contador] = totalComJuros;
                    System.out.println("Total com juros: " + String.format("%.2f", totais[contador]));
                    System.out.println("Valor por prestacao: " + String.format("%.2f", totais[contador] / np));

                } else {
                    System.out.println("Opcao invalida. Operacao cancelada.");
                    continue;
                }

                datas[contador] = sdf.format(new Date());
                System.out.println("Venda registada com sucesso! Numero: " + numeros[contador]);
                contador++;

            } else if (opcao == 2) {
                if (contador == 0) {
                    System.out.println("Nenhuma venda registada.");
                } else {
                    System.out.println("\n=== LISTAGEM DE VENDAS ===");
                    for (int i = 0; i < contador; i++) {
                        System.out.println("--------------------------------");
                        System.out.println("Numero da operacao : " + numeros[i]);
                        System.out.println("Nome do cliente    : " + nomes[i]);
                        System.out.println("Valor da compra    : " + String.format("%.2f", valores[i]));

                        if (formas[i] == 1) {
                            System.out.println("Forma de pagamento : A vista");
                        } else if (formas[i] == 2) {
                            System.out.println("Forma de pagamento : 2 prestacoes");
                        } else {
                            System.out.println("Forma de pagamento : " + prestacoes[i] + " prestacoes");
                        }

                        System.out.println("Total a pagar      : " + String.format("%.2f", totais[i]));
                        System.out.println("Data da venda      : " + datas[i]);
                    }
                    System.out.println("--------------------------------");
                }

            } else if (opcao == 3) {
                continuar = false;
                System.out.println("Sistema encerrado.");
            } else {
                System.out.println("Opcao invalida!");
            }
        }

        scanner.close();
    }
}
